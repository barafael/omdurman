# Handoff: Title screen 2a (animated map fade), for `omdurman-app`

Target file: `omdurman-app/src/splash.rs` (`splash_ui`). Reference design: option **2a** in `Title Screen.dc.html` in this project.

## Goal

Replace the flat `SPLASH_BACKDROP` fill with this layout:

- **Left third (dark):** the menu column (kicker, title, quote, buttons), left-aligned and vertically centred.
- **Right two thirds:** a period map of the battlefield. It pans slowly in broad Lissajous curves and gently changes its tilt and rotation. It is slightly blurred and sepia-toned.
- **Horizontal gradient:** fades from solid backdrop colour into the map. There are also weak top and bottom scrims.

Existing behaviour stays as it is:
- The `Loading…` state.
- The `bg_alpha` of 200 when returning via **M**. Apply it to the whole composition, including the map tint.
- The fullscreen blocker.
- The Lobby/Game logic and the disabled hover text.

Every look-and-feel number must be a `const` in one block at the top of `splash.rs` (or in `splash/params.rs`), so the screen can be retuned without touching the logic.

## Asset

- Source: *The Battlefield of Omdurman. From the actual Map used by Lord Kitchener during the Battle*. Public domain, from Wikimedia Commons: `File:The Battlefield of Omdurman. From the actual Map used by Lord Kitchener during the Battle.png` (1583×2820).
- In this project: `maps/kitchener_battlefield.png`.
- Add it as `omdurman-app/assets/splash_map.webp`. Target width 1600 px or less and quality around 80, so the WASM download stays small.
- Load it through the `AssetServer` like `fall_of_khartoum_1885.webp`. Do **not** gate `loaded` on it. If it isn't ready yet, draw only the backdrop.
- Register it with egui through `EguiContexts::add_image` (a bevy_egui `EguiTextureHandle`). Keep the returned `egui::TextureId` in a resource, for example `SplashMapTexture(Option<egui::TextureId>)`.
- Alternates tried in the design, all public domain, selectable with the `MAP` const if you add them:
  - Churchill, *The River War* (1899), "Battle of Omdurman, 6.45 a.m."
  - War Office sketch map, Sept. 1898

## Tweak constants (defaults = values the user settled on)

```rust
// -- Splash map (option 2a) --------------------------------------------------
/// Fraction of the screen width covered by the map region (right-anchored).
const MAP_REGION_W: f32 = 0.703;          // 900 / 1280
/// Map image is drawn as a square this many times the region's height…
const MAP_SIZE_REL_H: f32 = 1.875;        // 1500 / 800
/// …offset from the region's top-left by these fractions of region height.
const MAP_OFFSET_REL: egui::Vec2 = egui::vec2(-0.375, -0.4375); // (-300, -350) / 800
const MAP_SCALE: f32 = 1.12;              // extra zoom so tilted edges never show

const MAP_TILT_DEG: f32 = 37.0;           // base rotateX (0 = flat)
const MAP_TILT_SWING_DEG: f32 = 10.0;     // tilt = base + swing + swing·sin(...)  (clamped ≥ 0)
const MAP_ROTATE_DEG: f32 = -12.0;        // base rotateZ
const MAP_ROTATE_SWING_DEG: f32 = 4.0;
const MAP_GRID: usize = 24;              // mesh subdivisions per side
const MAP_PERSPECTIVE_REL_H: f32 = 1.375; // CSS perspective 1100px / 800
const MAP_PERSPECTIVE_ORIGIN: egui::Vec2 = egui::vec2(0.40, 0.40); // in region
const MAP_TRANSFORM_ORIGIN: egui::Vec2 = egui::vec2(0.50, 0.45);   // in image

const MAP_PAN: bool = true;
const MAP_PAN_SPEED: f32 = 0.5;           // time multiplier
/// Pan amplitudes as fractions of region height (150px, 40px @ 800).
const MAP_PAN_AMP_MAJOR: f32 = 0.1875;
const MAP_PAN_AMP_MINOR: f32 = 0.05;
/// Periods in seconds; keep them mutually incommensurate so the path never repeats.
const MAP_PERIOD_X: (f32, f32) = (53.0, 19.0);
const MAP_PERIOD_Y: (f32, f32) = (37.0, 23.0);
const MAP_PERIOD_TILT: f32 = 29.0;
const MAP_PERIOD_ROT: f32 = 61.0;

const MAP_BLUR_PX: f32 = 1.5;             // gaussian sigma, baked once at load (see below)
const MAP_BRIGHTNESS: f32 = 0.85;         // multiply
const MAP_SEPIA: f32 = 0.35;              // 0..1 mix toward sepia

/// Horizontal fade: (x as fraction of screen width, backdrop alpha 0..1).
const FADE_STOPS: [(f32, f32); 5] = [(0.0, 1.0), (0.37, 1.0), (0.46, 0.8), (0.60, 0.3), (0.75, 0.0)];
/// Vertical scrims: (y fraction, alpha).
const SCRIM_STOPS: [(f32, f32); 4] = [(0.0, 0.5), (0.18, 0.0), (0.82, 0.0), (1.0, 0.6)];

// -- Menu column -------------------------------------------------------------
const COL_LEFT_REL: f32 = 0.05625;        // 72 / 1280
const COL_W_REL: f32 = 0.367;             // 470 / 1280
const KICKER: &str = "KHARTOUM 1885 · OMDURMAN 1898";
const KICKER_SIZE: f32 = 14.0;
const KICKER_TRACKING: f32 = 0.28;        // em; egui: TextFormat::extra_letter_spacing = size·tracking
const TITLE_SIZE: f32 = 56.0;             // bold, two lines: "REMEMBER" / "GORDON!"
const QUOTE_SIZE: f32 = 22.0;
const QUOTE_WRAP: f32 = 360.0;
const ATTR_SIZE: f32 = 16.0;
const BUTTON_SIZE: egui::Vec2 = egui::vec2(300.0, 44.0);
const BUTTON_TEXT: f32 = 21.0;
const BUTTON_PAD_X: f32 = 18.0;           // label left-aligned
const GAP_KICKER_TITLE: f32 = 16.0;
const GAP_TITLE_QUOTE: f32 = 36.0;
const GAP_QUOTE_ATTR: f32 = 12.0;
const GAP_ATTR_BUTTONS: f32 = 44.0;
const GAP_BUTTONS: f32 = 10.0;
```

Colours come from the existing `crate::ui::palette` in `omdurman-app/src/ui.rs`:

| Element | Colour |
| --- | --- |
| Backdrop / fade colour | `SPLASH_BACKDROP` (gray 16) |
| Title | `SPLASH_TITLE` (214,178,106) |
| Quote | `TEXT_STRONG` |
| Attribution | `TEXT_MUTED` |
| Button fill / border | `NEUTRAL_FILL` / `NEUTRAL_BORDER` (keep the existing widget-visuals override block) |
| Kicker | new const `SPLASH_KICKER = rgb(170,155,110)`, the same value as `BRASS_DIM`, which you can reuse |
| Disabled Game button | fill gray 24, border gray 51, text `TEXT_DISABLED` |
| Map credit, bottom-right, 12 px italic | (180,171,152) |

Map credit text: *The Battlefield of Omdurman, from the map used by Lord Kitchener*.

## Rendering approach

egui has no 3D transforms and no blur, so do the following.

1. **Perspective quad as an `egui::Mesh`.** Build an N×N grid (`MAP_GRID = 24`) of textured vertices covering the image rect. Project each vertex on the CPU (math below) and push triangles with UVs. Subdividing gives near-perspective-correct texturing, because egui interpolates UVs affinely per triangle. Clip to the map region with `ui.painter().with_clip_rect(region)`.

   Tint each vertex with `Color32::from_rgb(b·s.r, b·s.g, b·s.b)`, where `b = MAP_BRIGHTNESS` and `s` is the sepia colour from step 2, scaled by `bg_alpha`. This gives brightness and alpha for free.

2. **Blur and sepia, baked once.** When the image asset finishes loading, and before handing it to egui:
   - Gaussian-blur the RGBA buffer with sigma `MAP_BLUR_PX · (texture_px / displayed_px)`. `image::imageops::blur` is fine. It is one-off cost; on WASM do it in the `Update` system the frame the asset loads.
   - Apply the sepia mix to the pixels (standard sepia matrix, lerped by `MAP_SEPIA`).

   If `MAP_BLUR_PX == 0.0`, skip the blur.

3. **Gradients** are two more `egui::Mesh`es:
   - Horizontal: one quad strip, a vertex pair per `FADE_STOPS` entry, colour `SPLASH_BACKDROP` at the stop's alpha × `bg_alpha`.
   - Vertical scrims: the same with `SCRIM_STOPS`.

   Paint order: backdrop fill → map mesh → horizontal fade → vertical scrim → text/buttons.

4. **Repaint.** While the splash or menu is visible and `MAP_PAN` is on, call `ctx.request_repaint()`. Accumulate time in a `Local<f32>` (`t += dt · MAP_PAN_SPEED`) rather than using wall-clock time, so pausing or changing speed has no jumps.

### Projection math (mirrors the CSS exactly)

Let `R` be the map region rect, `H = R.height()` and `S = MAP_SIZE_REL_H · H` (the image side length).

- Image top-left: `I0 = R.min + MAP_OFFSET_REL · H`.
- Transform origin: `O = I0 + MAP_TRANSFORM_ORIGIN · S`.
- Perspective eye, looking down −z: `E = R.min + MAP_PERSPECTIVE_ORIGIN · R.size()`, at distance `d = MAP_PERSPECTIVE_REL_H · H`.

Per frame (τ = 2π):

```
x    = H·(A·sin(τt/53)       + a·sin(τt/19 + 1.3))
y    = H·(A·sin(τt/37 + 0.7) + a·cos(τt/23))
tilt = max(0, MAP_TILT_DEG + SWING + SWING·sin(τt/29 + 2.1))
rot  = MAP_ROTATE_DEG + ROT_SWING·sin(τt/61)
```

Here `A = MAP_PAN_AMP_MAJOR` and `a = MAP_PAN_AMP_MINOR`.

For each grid point `P` (2D, in screen space):

```
p  = P − O                                      // relative to transform origin
p *= MAP_SCALE                                  // scale (applied first, CSS is right-to-left)
p  = rotZ(rot) · p                              // (px,py) → (px c − py s, px s + py c)
(px, py, pz) = (p.x, p.y·cos(tilt), p.y·sin(tilt))   // rotateX: +y tips away from the viewer
p3 = (px, py, pz) + (x, y, 0)                   // translate (outermost)
Q  = O + p3.xy                                  // back to screen
k  = d / (d + p3.z)                             // pz > 0 is farther away
screen = E + (Q − E)·k
```

Check the sign of the tilt against the design: the **top** of the map should recede, so the top edge gets narrower. If it looks inverted, flip the sign of `pz`.

## Menu column layout

Use `ui.allocate_new_ui` with a rect of `x = COL_LEFT_REL·w`, `width = COL_W_REL·w`, full height, and a left-aligned top-down layout.

To centre the content vertically, measure the stack once (galley heights plus gaps) and add `(h − stack_h)/2` of top space. Contents, top to bottom:

1. **Kicker:** Merriweather Regular, tracked, `SPLASH_KICKER`.
2. **Title:** Merriweather Bold, two lines. Egui's `Garamond` family already falls back to Bold at Lowest priority; register a dedicated `"GaramondBold"` family, the same way `GaramondItalic` is registered, so the title is really bold.
3. **Quote:** use the existing `emphasis_job`, with `halign: Align::LEFT` and wrap `QUOTE_WRAP`. Add an `halign` parameter to it rather than duplicating it. Keep the random quote from `quotes.md`. Some quotes are long, so the vertical centring must use the measured height.
4. **Attribution:** `emphasis_job`, upright, with `*Title*` runs in italic.
5. **Buttons:** Lobby, then Game. Keep the existing enable logic. Labels are left-aligned: use `egui::Button::new(..).min_size(BUTTON_SIZE)` and set `ui.style_mut().spacing.button_padding.x = BUTTON_PAD_X`. Egui buttons centre their label, so either wrap it in a left layout or paint the label yourself inside `ui.allocate_exact_size` + `ui.interact`.
6. **Loading state:** while `!loaded`, show `Loading…` in place of the buttons, as today.

On narrow windows (`w < 900`), fall back to the current centred single column with the map full-bleed behind it, and use a stronger uniform scrim instead of the horizontal fade.

## Acceptance

- At 1280×800 the screen matches 2a in `Title Screen.dc.html` when that file's Tweaks are set to: tilt 37, rotate −12, blur 1.5, speed 0.5, brightness 0.85.
- No map edge is ever visible during a 10-minute run at defaults.
- No map label shows through behind the title or quote; the column area stays solid backdrop.
- Changing any constant needs no other code edits.
- The M-key return still shows the board through the screen at `bg_alpha = 200`.
